/**
  ******************************************************************************
  * @file    main.c
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private define ------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private user code ---------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/

#define TX_Pin 6

const char HEXCODE[] = "0123456789ABCDEF";
char HEXBUF[128];

char * toHEX(const char * hex, uint8_t cnt, char pref)
{
  char a = 0;
  uint8_t c = 0;
  while(cnt--)
  {
    a = *hex++;
    if (pref) HEXBUF[c++] = pref;
    HEXBUF[c++] = HEXCODE[a >> 4];
    HEXBUF[c++] = HEXCODE[a & 0xf];
  }
  HEXBUF[c] = '\0';
  return HEXBUF;
} 

void Send_Byte(char const Msg)
{
  while(!(USART1->SR & 0x1UL << 7));
  USART1->DR = Msg;
}

void Send_String(char const * Msg)
{
  while(*Msg)
  {
    Send_Byte(*Msg++);
  }
}

int main(void)
{
  /* Reset of all peripherals, Initializes the Systick. */
  RCC->IOPENR |= RCC_IOPENR_GPIOAEN;
  RCC->APBENR2 |= RCC_APBENR2_USART1EN;

  GPIOA->MODER   |= (0x2uL << (TX_Pin * 2));  // MODE AF = b10
  GPIOA->OSPEEDR |= (0x3UL << (TX_Pin * 2));  // SPEED Very Fast = b11
  GPIOA->AFR[0]  |= (0x1UL << (TX_Pin * 4));  // AF1 for PA7 = USART TX

  USART1->BRR   = 24000000 / 115200;
  USART1->CR1   |= ((0x1UL << 3) | (0x1UL << 13)); // TE = 1 UE = 1;

  /* System clock configuration */
  
  /* infinite loop */
  while (1)
  {
    Send_String("USART1 DUMP:\r\n");
    for(uint32_t i = USART1_BASE; i < USART1_BASE + 0x100; i+=16)
    {
      Send_String(toHEX((char*)&i, 8, 0));
      Send_String(": ");
      Send_String(toHEX((char*)i, 16, ' '));
      Send_String("\r\n");
    }
   
  }
}


/* ***** END OF FILE ***************** */
