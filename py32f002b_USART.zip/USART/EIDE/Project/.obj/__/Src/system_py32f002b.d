Project/.obj/__/Src/system_py32f002b.o: ../Src/system_py32f002b.c \
 ../../../../../../Drivers/CMSIS/Device/PY32F0xx/Include/py32f0xx.h \
 ../../../../../../Drivers/CMSIS/Device/PY32F0xx/Include/py32f002bx5.h \
 ../../../../../../Drivers/CMSIS/Include/core_cm0plus.h \
 ../../../../../../Drivers/CMSIS/Include/core_cmInstr.h \
 ../../../../../../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../../../../../../Drivers/CMSIS/Include/core_cmFunc.h \
 ../../../../../../Drivers/CMSIS/Device/PY32F0xx/Include/system_py32f0xx.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f0xx_hal.h \
 ../Inc/py32f002b_hal_conf.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f002b_hal_rcc.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f002b_hal_def.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f0xx_hal.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f002b_hal_rcc_ex.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f002b_hal_gpio.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f002b_hal_gpio_ex.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f002b_hal_cortex.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f002b_hal_flash.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f002b_hal_pwr.h \
 ../../../../../../Drivers/PY32F002B_HAL_Driver/Inc/py32f002b_hal_uart.h
