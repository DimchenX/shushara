/**
  ******************************************************************************
  * @file    main.c
  * @author  MCU Application Team
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by Puya under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

#define TX_Pin 4

const char HEXCODE[] = "0123456789ABCDEF";
char HEXBUF[128];

char * toHEX_I(const uint32_t Chi)
{
  uint32_t sInt = Chi;
	uint8_t i = 8;
	while(i)
	{
		i--;
		HEXBUF[i] = HEXCODE[sInt & 0xF];
		sInt = sInt >> 4;
	}
	HEXBUF[8] = 0;
	return HEXBUF; 	
} 

char * toHEX(const char * hex, uint8_t cnt, char pref)
{
  char a = 0;
  uint8_t c = 0;
  while(cnt--)
  {
    a = *hex++;
    if (pref) HEXBUF[c++] = pref;
    HEXBUF[c++] = HEXCODE[a >> 4];
    HEXBUF[c++] = HEXCODE[a & 0xf];
  }
  HEXBUF[c] = '\0';
  return HEXBUF;
} 

void Send_Byte(char const Msg)
{
  while(!(USART1->SR & 0x1UL << 7));
  USART1->DR = Msg;
}

void Send_String(char const * Msg)
{
  while(*Msg)
  {
    Send_Byte(*Msg++);
  }
}

void DumpHEX(const char * Title, uint32_t addr, uint32_t count)
{
  Send_String(Title);
  for(uint32_t i = addr; i < addr + count; i+=0x10)
  {
    Send_String(toHEX_I(i));
    Send_String(": ");
    Send_String(toHEX((char*)i, 16, ' '));
    Send_String("\r\n");
  }
}


int main(void)
{
 
  RCC->IOPENR  |= RCC_IOPENR_GPIOBEN;
  RCC->APBENR2 |= RCC_APBENR2_USART1EN;

  uint32_t tmp; 
  tmp = GPIOB->MODER;
  tmp &= ~(0x3uL << (TX_Pin * 2));
  tmp |=  (0x2uL << (TX_Pin * 2));
  GPIOB->MODER = tmp;
  GPIOB->OSPEEDR |= (0x3UL << (TX_Pin * 2));  // SPEED Very Fast = b11
  GPIOB->AFR[0]  |= (0x1UL << (TX_Pin * 4));  // AF1 for PA7 = USART TX


  USART1->BRR   = 24000000 / 115200;
  USART1->CR1   |= (0x1UL << 3);   // TE = 1
  USART1->CR1   |= (0x1UL << 13);  // UE = 1

  while (1)
  {
    DumpHEX("\r\nUSART:\r\n", USART1_BASE, 0x20);
    DumpHEX("\r\nRCC:\r\n", RCC_BASE, 0x80);
    DumpHEX("\r\nGPIOA:\r\n", GPIOA_BASE, 0x40);
    DumpHEX("\r\nGPIOB:\r\n", GPIOB_BASE, 0x40);
    DumpHEX("\r\nGPIOC:\r\n", GPIOC_BASE, 0x40);
    DumpHEX("\r\nFlash:\r\n", 0x08000000, 0x800);
    for(uint32_t i = 24000000/2; i != 0; i--) ;
  }
}


